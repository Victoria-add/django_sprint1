#!/bin/sh
cat > /app/answer.json << 'JSON'
{
  "mappings": [
    {
      "term": "ЕПК ID",
      "quote": "Сервис поиска клиента по ЕПК ID",
      "path": "individual.id",
      "condition": null,
      "justification": "Прямое соответствие (Алгоритм 1): атрибут id объекта individual."
    },
    {
      "term": "ФИО",
      "quote": "в ответ возвращает ФИО, ДР, гражданство",
      "path": "individual.names",
      "condition": null,
      "justification": "Прямое соответствие (Алгоритм 1): атрибут names объекта individual."
    },
    {
      "term": "ДР",
      "quote": "в ответ возвращает ФИО, ДР, гражданство",
      "path": "individual.birthDate",
      "condition": null,
      "justification": "Прямое соответствие (Алгоритм 1): атрибут birthDate объекта individual."
    },
    {
      "term": "гражданство",
      "quote": "в ответ возвращает ФИО, ДР, гражданство",
      "path": "individual.countryResident",
      "condition": null,
      "justification": "Прямое соответствие (Алгоритм 1): атрибут countryResident объекта individual."
    },
    {
      "term": "серия",
      "quote": "серия и номер паспорта",
      "path": "individual.identifications.documentSeries",
      "condition": null,
      "justification": "Поиск по родительскому объекту identifications (Алгоритм 2)."
    },
    {
      "term": "номер паспорта",
      "quote": "серия и номер паспорта",
      "path": "individual.identifications.documentNumber",
      "condition": null,
      "justification": "Поиск по родительскому объекту identifications (Алгоритм 2)."
    },
    {
      "term": "кем выдан",
      "quote": "кем выдан",
      "path": "individual.identifications.issuedByOrganization",
      "condition": null,
      "justification": "Прямое соответствие (Алгоритм 1): атрибут issuedByOrganization."
    },
    {
      "term": "НМТ",
      "quote": "НМТ (номер мобильного телефона)",
      "path": "individual.phoneNumbers.phoneNumber",
      "condition": "usageType.code = 15",
      "justification": "Поиск по справочнику (Алгоритм 3): код 15 = мобильный телефон."
    },
    {
      "term": "адреса",
      "quote": "адреса",
      "path": "individual.addresses",
      "condition": null,
      "justification": "Обобщённое упоминание сущности — путь до объекта без условий (Алгоритм 2)."
    }
  ]
}
JSON
