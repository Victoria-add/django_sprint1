"""Verifier кейса data-mapping (структурированный answer.json).

Контракт reward:
- pass_to_pass — входные файлы на месте и не изменены агентом (sha256-контроль).
  Истинно и на base, и после решения; одновременно закрывает обход через подмену входов.
- fail_to_pass — детерминированная проверка answer.json: связка термин→цитата→путь→условие.
  На base файла нет → тесты падают; после solution/solve.sh → проходят.

Judge в контракте не используется: оценка полностью детерминирована (execution_test).
"""
import hashlib
import json
import os
import re

import pytest

APP = "/app"
ANSWER = os.path.join(APP, "answer.json")
SOURCE = os.path.join(APP, "business_requirement.txt")

# Контроль неизменности входов: агент должен менять только answer.json.
EXPECTED_INPUT_SHA256 = {
    "business_requirement.txt": "c4d555bbe31ab43c1294d9f7195473fce790130dc81bb9a269e4ebddc09e4b75",
    "01_common_rules.txt": "bd8d995bdabc4e5c1bf112feff27183ae1a9571cfd65acdb0ee3f94e44fd0ce1",
    "02_instruction.txt": "3c35656e88dc8d55fe7b70737b61c16ccb4057792a10b8e0d389189f2f985677",
    "03_data_and_references.json": "40aa8e72e630f7f467ee8fc3825556a0033956a2e7a56c53e46ba3d46ee71525",
}

# Полный набор допустимых путей модели (без условия — условие проверяется отдельно).
VALID_PATHS = {
    "individual.id",
    "individual.names",
    "individual.birthDate",
    "individual.countryResident",
    "individual.identifications.documentSeries",
    "individual.identifications.documentNumber",
    "individual.identifications.issuedByOrganization",
    "individual.phoneNumbers.phoneNumber",
    "individual.addresses",
}

# Обязательные сопоставления: ожидаемый путь + опорный термин (+ условие, если нужно).
REQUIRED = [
    {"path": "individual.id", "anchor": "ЕПК ID"},
    {"path": "individual.names", "anchor": "ФИО"},
    {"path": "individual.birthDate", "anchor": "ДР"},
    {"path": "individual.countryResident", "anchor": "гражданство"},
    {"path": "individual.identifications.documentSeries", "anchor": "серия"},
    {"path": "individual.identifications.documentNumber", "anchor": "номер паспорта"},
    {"path": "individual.identifications.issuedByOrganization", "anchor": "кем выдан"},
    {"path": "individual.phoneNumbers.phoneNumber", "anchor": "НМТ",
     "condition": r"usageType\.code\s*=\s*15"},
    {"path": "individual.addresses", "anchor": "адреса"},
]


def _norm(s):
    return (s or "").replace("ё", "е")


def _read(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def _load_answer():
    with open(ANSWER, "r", encoding="utf-8") as f:
        return json.load(f)


def _mappings():
    data = _load_answer()
    assert isinstance(data, dict), "answer.json должен быть JSON-объектом"
    maps = data.get("mappings")
    assert isinstance(maps, list) and maps, "поле mappings должно быть непустым массивом"
    return maps


# ── pass_to_pass: входы на месте и не изменены ────────────────────────────────

def test_inputs_present_and_untouched():
    """PASS_TO_PASS + anti-cheat: входные файлы существуют и побайтно не изменены."""
    for name, expected in EXPECTED_INPUT_SHA256.items():
        path = os.path.join(APP, name)
        assert os.path.exists(path), f"Входной файл отсутствует: {name}"
        actual = hashlib.sha256(_read(path).encode("utf-8")).hexdigest()
        assert actual == expected, f"Входной файл изменён агентом: {name}"


# ── fail_to_pass: проверка answer.json ────────────────────────────────────────

def test_answer_is_valid_json():
    """FAIL_TO_PASS: answer.json существует, корректный JSON, непустой mappings."""
    assert os.path.exists(ANSWER), "Файл answer.json не найден"
    _mappings()


def test_paths_valid():
    """FAIL_TO_PASS (K2): каждый путь существует в модели данных (нет галлюцинаций)."""
    invalid = sorted({m.get("path") for m in _mappings()} - VALID_PATHS)
    assert not invalid, f"Использованы несуществующие в модели пути: {invalid}"


def test_quotes_grounded():
    """FAIL_TO_PASS (привязка/сохранность): цитата дословно есть в источнике и содержит термин."""
    source = _norm(_read(SOURCE))
    for m in _mappings():
        term = _norm(m.get("term", ""))
        quote = _norm(m.get("quote", ""))
        assert quote, f"Пустая цитата в сопоставлении: {m.get('path')}"
        assert quote in source, f"Цитата не найдена дословно в источнике: {m.get('quote')!r}"
        assert term and term in quote, \
            f"Термин {m.get('term')!r} не содержится в своей цитате {m.get('quote')!r}"


def test_all_required_terms_mapped():
    """FAIL_TO_PASS (K1 — полнота + связка термин→путь): все обязательные сопоставления есть."""
    maps = _mappings()
    for req in REQUIRED:
        anchor = _norm(req["anchor"])
        found = [
            m for m in maps
            if m.get("path") == req["path"]
            and anchor in (_norm(m.get("term", "")) + " " + _norm(m.get("quote", "")))
        ]
        assert found, f"Нет корректного сопоставления для пути {req['path']} (термин ~ {req['anchor']!r})"


def test_nmt_condition():
    """FAIL_TO_PASS (K2 — условие): для НМТ задано условие usageType.code = 15."""
    pattern = re.compile(r"usageType\.code\s*=\s*15")
    nmt = [m for m in _mappings() if m.get("path") == "individual.phoneNumbers.phoneNumber"]
    assert nmt, "Нет сопоставления для НМТ (individual.phoneNumbers.phoneNumber)"
    assert any(pattern.search(_norm(m.get("condition") or "")) for m in nmt), \
        "Для НМТ не указано корректное условие usageType.code = 15"


def test_justifications_present():
    """FAIL_TO_PASS: у каждого сопоставления есть непустое обоснование."""
    for m in _mappings():
        assert (m.get("justification") or "").strip(), \
            f"Пустое обоснование для пути {m.get('path')}"
