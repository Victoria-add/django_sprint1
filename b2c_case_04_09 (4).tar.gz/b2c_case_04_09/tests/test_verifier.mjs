// Поведенческие проверки контракта js.js.
// fail_to_pass: падают на исходном (уязвимом) коде, проходят на корректном решении.
// pass_to_pass: проходят и до, и после решения (регрессия публичного интерфейса/поведения).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { loadModule } from './harness.mjs';

// ── fail_to_pass ─────────────────────────────────────────────────────────────

test('[fail_to_pass] XSS: displayUser вставляет данные как текст, не как HTML', () => {
  const { sandbox, getEl } = loadModule();
  const el = getEl('user-name');
  el.reset();
  const payload = '<img src=x onerror=alert(1)>';
  sandbox.displayUser(payload);
  assert.ok(
    !el.innerAssignments.some((v) => String(v).includes('<img')),
    'сырой HTML не должен присваиваться через innerHTML',
  );
  const asText = el.textContent || '';
  assert.ok(asText.includes(payload), 'данные должны выводиться как текстовое содержимое');
});

test('[fail_to_pass] fetch: неуспешный HTTP-ответ приводит к ошибке', async () => {
  const { sandbox } = loadModule();
  sandbox.fetch = async () => ({ ok: false, status: 500, json: async () => ({ secret: 'leak' }) });
  await assert.rejects(
    () => sandbox.fetchUserData('1'),
    'при статусе 5xx функция не должна возвращать тело как при успехе',
  );
});

test('[fail_to_pass] валидация: пустой userId отклоняется без обращения к сети', async () => {
  const { sandbox } = loadModule();
  let called = false;
  sandbox.fetch = async () => { called = true; return { ok: true, status: 200, json: async () => ({}) }; };
  await assert.rejects(() => sandbox.fetchUserData(''), 'пустой ввод должен отклоняться');
  assert.equal(called, false, 'при невалидном вводе сетевой вызов выполняться не должен');
});

test('[fail_to_pass] утечка: attachHandler возвращает снятие того же обработчика', () => {
  const { sandbox, listeners } = loadModule();
  const beforeAdd = listeners.add.length;
  const cleanup = sandbox.attachHandler();
  assert.equal(typeof cleanup, 'function', 'attachHandler должна возвращать функцию снятия');
  assert.equal(listeners.add.length, beforeAdd + 1, 'обработчик должен регистрироваться');
  const added = listeners.add[listeners.add.length - 1];
  cleanup();
  const removed = listeners.remove[listeners.remove.length - 1];
  assert.ok(
    removed && removed.fn === added.fn && removed.type === added.type,
    'cleanup должен снимать именно тот обработчик, что был добавлен',
  );
});

test('[fail_to_pass] eval: evaluateExpression не исполняет произвольный код', () => {
  // Harness создаёт vm-контекст с codeGeneration.strings=false — это запрещает eval(string)
  // и new Function(string) на уровне движка. Если evaluateExpression использует eval/Function,
  // она бросит EvalError. Если использует safe-parser — вернёт число.
  const { sandbox } = loadModule();

  // Арифметика должна работать через safe-parser, не через eval
  let result;
  assert.doesNotThrow(
    () => { result = sandbox.evaluateExpression('6 * 7'); },
    'evaluateExpression должна вычислять арифметику без eval/Function',
  );
  assert.equal(result, 42, 'результат должен быть числом 42');

  // Неарифметический ввод должен бросать ошибку
  assert.throws(
    () => sandbox.evaluateExpression('alert(1)'),
    'невалидный ввод должен приводить к ошибке',
  );
});

// ── pass_to_pass ──────────────────────────────────────────────────────────────

test('[pass_to_pass] публичный интерфейс: все функции на месте', () => {
  const { sandbox } = loadModule();
  for (const fn of ['displayUser', 'fetchUserData', 'attachHandler', 'evaluateExpression']) {
    assert.equal(typeof sandbox[fn], 'function', `${fn} должна быть функцией`);
  }
});

test('[fail_to_pass] арифметика вычисляется через safe-parser (не eval)', () => {
  // В harness eval/Function запрещены на уровне vm-контекста.
  // Этот тест падает на base (eval бросает EvalError) и проходит на safe-parser.
  const { sandbox } = loadModule();
  assert.equal(sandbox.evaluateExpression('2 + 3'), 5);
  assert.equal(sandbox.evaluateExpression('2 * (3 + 4)'), 14);
});

test('[pass_to_pass] displayUser показывает обычное имя', () => {
  const { sandbox, getEl } = loadModule();
  const el = getEl('user-name');
  el.reset();
  sandbox.displayUser('Alice');
  const shown = String(el.textContent || '') + String(el.innerHTML || '');
  assert.ok(shown.includes('Alice'), 'обычное имя должно отображаться');
});

test('[pass_to_pass] fetchUserData возвращает данные при успехе', async () => {
  const { sandbox } = loadModule();
  sandbox.fetch = async () => ({ ok: true, status: 200, json: async () => ({ name: 'Bob' }) });
  const data = await sandbox.fetchUserData('7');
  assert.equal(data.name, 'Bob');
});

test('[pass_to_pass] сетевая ошибка пробрасывается', async () => {
  const { sandbox } = loadModule();
  sandbox.fetch = async () => { throw new Error('network down'); };
  await assert.rejects(() => sandbox.fetchUserData('1'), 'сетевая ошибка должна приводить к отклонению');
});
