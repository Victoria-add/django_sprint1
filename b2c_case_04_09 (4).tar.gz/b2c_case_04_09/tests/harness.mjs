// Изолированный загрузчик проверяемого скрипта.
// Запускается из неизменяемой директории /tests; читает только /app/js.js
// и исполняет его в песочнице vm с подменёнными document/window/fetch/console.
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const SRC = '/app/js.js';

function makeElement(id) {
  let _inner = '';
  let _text = '';
  const el = {
    id,
    value: '42',
    innerAssignments: [],
    textAssignments: [],
    get innerHTML() { return _inner; },
    set innerHTML(v) { _inner = v; el.innerAssignments.push(v); },
    get textContent() { return _text; },
    set textContent(v) { _text = v; el.textAssignments.push(v); },
    reset() { _inner = ''; _text = ''; el.innerAssignments = []; el.textAssignments = []; },
  };
  return el;
}

export function loadModule() {
  const elements = new Map();
  const getEl = (id) => {
    if (!elements.has(id)) elements.set(id, makeElement(id));
    return elements.get(id);
  };
  const listeners = { add: [], remove: [] };

  const sandbox = {
    document: { getElementById: (id) => getEl(id) },
    window: {
      addEventListener: (type, fn) => listeners.add.push({ type, fn }),
      removeEventListener: (type, fn) => listeners.remove.push({ type, fn }),
    },
    console: { log() {}, error() {}, warn() {}, info() {} },
    // Безопасный fetch по умолчанию: успешный ответ. Переопределяется в тестах.
    fetch: async () => ({ ok: true, status: 200, json: async () => ({ name: 'default' }) }),

  };

  // codeGeneration.strings=false блокирует eval(string) и new Function(string) на уровне vm-контекста.
  // Это позволяет детектировать использование eval без side-effect хаков.
  vm.createContext(sandbox, { codeGeneration: { strings: false, wasm: false } });
  const code = readFileSync(SRC, 'utf8');
  vm.runInContext(code, sandbox, { filename: 'js.js' });
  return { sandbox, getEl, listeners, noCodeGen: true };
}
