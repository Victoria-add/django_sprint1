#!/bin/sh
set -e

mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt

# Запуск из неизменяемой директории с тестами; проверяемый код читается по
# абсолютному пути /app/js.js и исполняется в изолированной vm-песочнице.
cd /tests
if node --test /tests/test_verifier.mjs > /logs/verifier/node.log 2>&1; then
    echo 1 > /logs/verifier/reward.txt
fi
