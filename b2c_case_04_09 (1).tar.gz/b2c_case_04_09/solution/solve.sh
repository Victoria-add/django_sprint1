#!/bin/sh
cat > /app/js.js << 'JS'
// Глобальная конфигурация
let config = { apiUrl: 'https://api.example.com' };

// XSS устранён: данные вставляются как текст, а не как HTML
function displayUser(name) {
    document.getElementById('user-name').textContent = String(name);
}

// Валидация ввода + проверка статуса ответа
async function fetchUserData(userId) {
    if (typeof userId !== 'string' || userId.trim() === '') {
        throw new Error('Invalid userId');
    }
    const response = await fetch(`${config.apiUrl}/users/${encodeURIComponent(userId)}`);
    if (!response.ok) {
        throw new Error(`HTTP error: ${response.status}`);
    }
    return await response.json();
}

// Утечка устранена: возвращаем функцию снятия обработчика
function attachHandler() {
    const handler = function() { console.log('Resize'); };
    window.addEventListener('resize', handler);
    return function cleanup() {
        window.removeEventListener('resize', handler);
    };
}

// Безопасное вычисление арифметики без eval/Function
function evaluateExpression(expr) {
    return safeEvalArithmetic(String(expr));
}

function safeEvalArithmetic(input) {
    const s = input;
    let pos = 0;
    const skip = () => { while (pos < s.length && s[pos] === ' ') pos++; };
    function parseExpr() {
        let v = parseTerm();
        skip();
        while (pos < s.length && (s[pos] === '+' || s[pos] === '-')) {
            const op = s[pos++];
            const t = parseTerm();
            v = op === '+' ? v + t : v - t;
            skip();
        }
        return v;
    }
    function parseTerm() {
        let v = parseFactor();
        skip();
        while (pos < s.length && (s[pos] === '*' || s[pos] === '/')) {
            const op = s[pos++];
            const f = parseFactor();
            v = op === '*' ? v * f : v / f;
            skip();
        }
        return v;
    }
    function parseFactor() {
        skip();
        if (s[pos] === '(') {
            pos++;
            const v = parseExpr();
            skip();
            if (s[pos] !== ')') throw new Error('Expected )');
            pos++;
            return v;
        }
        const start = pos;
        if (s[pos] === '+' || s[pos] === '-') pos++;
        while (pos < s.length && ((s[pos] >= '0' && s[pos] <= '9') || s[pos] === '.')) pos++;
        const num = s.slice(start, pos);
        if (num === '' || isNaN(Number(num))) throw new Error('Invalid number');
        return Number(num);
    }
    const result = parseExpr();
    skip();
    if (pos !== s.length) throw new Error('Unexpected token');
    return result;
}

const userId = document.getElementById('user-id-input').value;
fetchUserData(userId).then(displayUser).catch(function() {});
JS
