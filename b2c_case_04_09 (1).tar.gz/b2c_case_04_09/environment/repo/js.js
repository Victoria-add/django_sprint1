// Глобальная конфигурация
let config = { apiUrl: 'https://api.example.com' };

// Уязвимость: XSS при вставке данных в DOM
function displayUser(name) {
    document.getElementById('user-name').innerHTML = name; // Опасно!
}

// Логика: не проверяется статус ответа, нет валидации ввода
async function fetchUserData(userId) {
    const response = await fetch(`${config.apiUrl}/users/${userId}`);
    const data = await response.json();
    return data;
}

// Утечка памяти: обработчик нельзя снять
function attachHandler() {
    window.addEventListener('resize', function() { console.log('Resize'); });
    // Нет соответствующего removeEventListener
}

// Небезопасное вычисление выражений
function evaluateExpression(expr) {
    return eval(expr); // ОЧЕНЬ ОПАСНО
}

const userId = document.getElementById('user-id-input').value;
fetchUserData(userId).then(displayUser);
