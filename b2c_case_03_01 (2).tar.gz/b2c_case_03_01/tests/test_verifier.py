"""Verifier кейса data-mapping (свободный текст answer.txt).

Контракт reward:
- pass_to_pass — входы на месте и не изменены (sha256) + модель данных согласована.
  Истинно и на base, и после решения; закрывает обход через подмену входов.
- fail_to_pass — разбор answer.txt: техническое описание + по-элементные блоки
  обоснования со связкой термин -> путь -> цитата -> условие.

Judge в контракте не используется: оценка полностью детерминирована (execution_test).
"""
import hashlib
import os
import re

import pytest

APP = "/app"
ANSWER = os.path.join(APP, "answer.txt")
SOURCE = os.path.join(APP, "business_requirement.txt")
MODEL = os.path.join(APP, "03_data_and_references.json")

# Контроль неизменности входов: агент должен менять только answer.txt.
EXPECTED_INPUT_SHA256 = {
    "business_requirement.txt": "c4d555bbe31ab43c1294d9f7195473fce790130dc81bb9a269e4ebddc09e4b75",
    "01_common_rules.txt": "bd8d995bdabc4e5c1bf112feff27183ae1a9571cfd65acdb0ee3f94e44fd0ce1",
    "02_instruction.txt": "3c35656e88dc8d55fe7b70737b61c16ccb4057792a10b8e0d389189f2f985677",
    "03_data_and_references.json": "40aa8e72e630f7f467ee8fc3825556a0033956a2e7a56c53e46ba3d46ee71525",
}

VALID_PATHS = {
    "individual.id",
    "individual.names",
    "individual.birthDate",
    "individual.countryResident",
    "individual.identifications.documentSeries",
    "individual.identifications.documentNumber",
    "individual.identifications.issuedByOrganization",
    "individual.phoneNumbers.phoneNumber",
    "individual.phoneNumbers.usageType.code",
    "individual.addresses",
}

# Обязательные сопоставления: ожидаемый путь + опорный термин (+ условие, если нужно).
REQUIRED = [
    {"path": "individual.id", "anchor": "ЕПК ID"},
    {"path": "individual.names", "anchor": "ФИО"},
    {"path": "individual.birthDate", "anchor": "ДР"},
    {"path": "individual.countryResident", "anchor": "гражданство"},
    {"path": "individual.identifications.documentSeries", "anchor": "серия"},
    {"path": "individual.identifications.documentNumber", "anchor": "номер паспорта"},
    {"path": "individual.identifications.issuedByOrganization", "anchor": "кем выдан"},
    {"path": "individual.phoneNumbers.phoneNumber", "anchor": "НМТ",
     "condition": r"usageType\.code\s*=\s*15"},
    {"path": "individual.addresses", "anchor": "адреса"},
]

PATH_RE = re.compile(r"individual(?:\.[A-Za-z0-9]+)+")
TECH_MARKER = "Техническое описание доработки"
JUST_MARKER = "Обоснование примененных кодов и значений"


def _norm(s):
    return (s or "").replace("ё", "е")


def _read(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def _answer():
    return _read(ANSWER)


def _technical_part(content):
    norm = _norm(content)
    return norm.split(JUST_MARKER)[0] if JUST_MARKER in norm else norm


def _justification_part(content):
    norm = _norm(content)
    parts = norm.split(JUST_MARKER)
    return parts[1] if len(parts) > 1 else ""


def _field(block_text, name):
    m = re.search(rf"{name}\s*:\s*(.+)", block_text)
    return m.group(1).strip() if m else ""


def _parse_blocks(content):
    """Разбирает блоки обоснования вида '## Элемент: <term> -> <path>' + поля."""
    just = _justification_part(content)
    raw_blocks = re.split(r"^##\s*Элемент:", just, flags=re.MULTILINE)[1:]
    blocks = []
    for rb in raw_blocks:
        lines = rb.splitlines()
        head = lines[0] if lines else ""
        path_m = PATH_RE.search(head)
        blocks.append({
            "head": head.strip(),
            "path": path_m.group(0) if path_m else None,
            "quote": _field(rb, "Цитата"),
            "logic": _field(rb, "Логика"),
            "relevant_data": _field(rb, "Релевантные данные"),
            "conclusion": _field(rb, "Умозаключение"),
        })
    return blocks


# ── pass_to_pass: окружение и согласованность модели ──────────────────────────

def test_inputs_present_and_untouched():
    """PASS_TO_PASS + anti-cheat: входные файлы существуют и побайтно не изменены."""
    for name, expected in EXPECTED_INPUT_SHA256.items():
        path = os.path.join(APP, name)
        assert os.path.exists(path), f"Входной файл отсутствует: {name}"
        actual = hashlib.sha256(_read(path).encode("utf-8")).hexdigest()
        assert actual == expected, f"Входной файл изменён агентом: {name}"


def test_data_model_paths_consistent():
    """PASS_TO_PASS: технические имена путей реально присутствуют в модели данных."""
    model = _read(MODEL)
    leaves = [
        "id", "names", "birthDate", "countryResident",
        "documentSeries", "documentNumber", "issuedByOrganization",
        "phoneNumber", "addresses", "usageType",
    ]
    missing = [name for name in leaves if name not in model]
    assert not missing, f"В модели данных отсутствуют имена: {missing}"
    assert "15" in model, "В справочнике нет кода 15 (мобильный телефон)"


# ── fail_to_pass: разбор answer.txt ───────────────────────────────────────────

def test_answer_file_exists():
    """FAIL_TO_PASS: файл с ответом создан."""
    assert os.path.exists(ANSWER), "Файл answer.txt не найден"


def test_answer_has_two_sections():
    """FAIL_TO_PASS: присутствуют оба раздела (техническое описание и обоснование)."""
    norm = _norm(_answer())
    assert TECH_MARKER in norm, "Нет раздела технического описания"
    assert JUST_MARKER in norm, "Нет раздела обоснования"


def test_all_required_paths_present():
    """FAIL_TO_PASS (K1 — полнота): все обязательные пути есть в техническом описании."""
    technical = _technical_part(_answer())
    missing = [r["path"] for r in REQUIRED if r["path"] not in technical]
    assert not missing, f"В техническом описании отсутствуют пути: {missing}"


def test_no_hallucinated_paths():
    """FAIL_TO_PASS (K2): использованы только пути, существующие в модели данных."""
    found = set(PATH_RE.findall(_answer()))
    invalid = sorted(found - VALID_PATHS)
    assert not invalid, f"Использованы несуществующие в модели пути: {invalid}"


def test_each_element_has_required_blocks():
    """FAIL_TO_PASS: для каждого обязательного сопоставления есть блок со связкой
    термин -> путь, дословной цитатой и полями обоснования (Логика/Данные/Умозаключение)."""
    content = _answer()
    source = _norm(_read(SOURCE))
    blocks = _parse_blocks(content)
    assert blocks, "Не найдено ни одного блока '## Элемент:'"

    for req in REQUIRED:
        anchor = _norm(req["anchor"])
        match = None
        for b in blocks:
            if b["path"] == req["path"] and anchor in _norm(b["head"]):
                match = b
                break
        assert match, f"Нет блока обоснования для {req['path']} (термин ~ {req['anchor']!r})"

        quote = _norm(match["quote"]).strip().strip('"').strip()
        assert quote, f"Пустая цитата для {req['path']}"
        assert quote in source, f"Цитата не найдена дословно в источнике: {match['quote']!r}"
        assert anchor in quote, f"Термин {req['anchor']!r} не содержится в своей цитате"

        for field_key, field_name in (("logic", "Логика"),
                                      ("relevant_data", "Релевантные данные"),
                                      ("conclusion", "Умозаключение")):
            assert match[field_key], f"Пустое поле '{field_name}' для {req['path']}"


def test_nmt_condition():
    """FAIL_TO_PASS (K2 — условие): для НМТ задано условие usageType.code = 15."""
    technical = _technical_part(_answer())
    assert re.search(r"individual\.phoneNumbers\.usageType\.code\s*=\s*15", technical), \
        "Для НМТ не указано корректное условие usageType.code = 15"


def test_condition_only_where_required():
    """FAIL_TO_PASS (anti-cheat): условие usageType.code не навешивается на адреса."""
    technical = _technical_part(_answer())
    assert not re.search(r"individual\.addresses[^\n]*usageType\.code\s*=", technical), \
        "Для обобщённых 'адреса' условие usageType.code не требуется"


def test_no_duplicate_elements():
    """FAIL_TO_PASS (anti-cheat): нет дублирующих блоков по одному и тому же пути."""
    paths = [b["path"] for b in _parse_blocks(_answer()) if b["path"]]
    dups = sorted({p for p in paths if paths.count(p) > 1})
    assert not dups, f"Дублирующие блоки обоснования для путей: {dups}"


def test_original_terms_preserved():
    """FAIL_TO_PASS (сохранность): бизнес-термины не удалены из технического описания."""
    technical = _technical_part(_answer())
    for term in ("ЕПК ID", "ФИО", "гражданство", "паспорт", "НМТ", "адрес"):
        assert term in technical, f"Бизнес-термин '{term}' удалён — должен сохраняться"
