#!/bin/sh
set -e

mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt

# Изоляция: запуск из неизменяемой /tests; -P не добавляет cwd/скрипт-каталог в sys.path,
# поэтому файлы из рабочей папки агента (/app) не влияют на прогон проверки.
cd /tests
if python -P -m pytest /tests/test_verifier.py -p no:cacheprovider -q \
        > /logs/verifier/pytest.log 2>&1; then
    echo 1 > /logs/verifier/reward.txt
fi
